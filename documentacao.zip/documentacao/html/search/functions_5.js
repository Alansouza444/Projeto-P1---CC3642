var searchData=
[
  ['setfabrica',['setFabrica',['../class_veiculo.html#a8201bb998eb49364bb5d5bb05ce531ab',1,'Veiculo']]],
  ['setx',['setX',['../class_veiculo.html#a28cf763354cb7f3d14272c9e793db57e',1,'Veiculo']]],
  ['sety',['setY',['../class_veiculo.html#ac0356427caf9839b90e558c99c09395f',1,'Veiculo']]]
];
