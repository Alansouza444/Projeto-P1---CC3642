var searchData=
[
  ['getcor',['getCor',['../class_veiculo.html#ad1df848daf28895b13071d6dec374480',1,'Veiculo']]],
  ['getfabrica',['getFabrica',['../class_veiculo.html#a6447f0eeb99399f1f96e835c22a88479',1,'Veiculo']]],
  ['getvel',['getVel',['../class_veiculo.html#ab43d327b067e15c1bc96cee94d495049',1,'Veiculo']]],
  ['getx',['getX',['../class_veiculo.html#a235b29e1e25ec8c769b20fb2aeba8404',1,'Veiculo']]],
  ['gety',['getY',['../class_veiculo.html#a06b2a923e51186673a016f75d10363d3',1,'Veiculo']]]
];
