var searchData=
[
  ['mapa',['mapa',['../class_mundo.html#a8332b2d52b9f317338a4d6cbe10bbcbb',1,'Mundo']]]
];
